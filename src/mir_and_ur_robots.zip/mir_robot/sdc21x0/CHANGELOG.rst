^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sdc21x0
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.4 (2021-12-10)
------------------

1.1.3 (2021-06-11)
------------------

1.1.2 (2021-05-12)
------------------

1.1.1 (2021-02-11)
------------------
* Contributors: Martin Günther

1.1.0 (2020-06-30)
------------------
* Initial release into noetic
* Contributors: Martin Günther

1.0.6 (2020-06-30)
------------------
* Set cmake_policy CMP0048 to fix warning
* Contributors: Martin Günther

1.0.5 (2020-05-01)
------------------
* Add sdc21x0 package, MC/currents topic
* Contributors: Martin Günther

* Add sdc21x0 package, MC/currents topic
* Contributors: Martin Günther

1.0.4 (2019-05-06)
------------------

1.0.3 (2019-03-04)
------------------

1.0.2 (2018-07-30)
------------------

1.0.1 (2018-07-17)
------------------

1.0.0 (2018-07-12)
------------------
